/**
 * Created by lhida on 29-01-2017.
 */
$("#back").click(function () {
    window.history.back();
})